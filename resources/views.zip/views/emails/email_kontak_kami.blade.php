<h2>Pesan Kontak Baru</h2>

<p>Nama: {{ $contact['nama'] }}</p>
<p>Email: {{ $contact['email'] }}</p>
<p>Telepon: {{ $contact['pertanyaan'] }}</p>
