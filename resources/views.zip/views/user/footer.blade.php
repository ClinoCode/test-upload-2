<div class="footer">
    <div class="container">
        <ul class="list-group">
            <li class="list-group-item company">Company | Recruit | Contact</li>
            <li class="list-group-item">Alamat : Jl Tebet Dalam III no 13, Jakarta Selatan, 12810</li>
            <li class="list-group-item">Email : doe@lezatsugihrasa.com</li>
            <li class="list-group-item">Customer Service : 021 8300 262</li>
            <li class="list-group-item">
                <div class="icon">
                    <a href="https://www.instagram.com/sekayucatering/"><img
                            src="{{ url('users/img/iconinstragram.svg') }}" alt="link instagram"></a>
                    <a href="https://www.youtube.com/@sekayucateringjakarta"><img
                            src="{{ url('users/img/iconyoutube.svg') }}" alt="link youtube"></a>
                    <a href="https://www.linkedin.com/company/sekayucatering/?originalSubdomain=id"><img
                            src="{{ url('users/img/iconlinkeln.svg') }}" alt="link linkedin"></a>
                    <a href="https://www.tiktok.com/@sekayucatering?is_from_webapp=1&sender_device=pc"><img
                            src="{{ url('users/img/icontiktok.svg') }}" alt="link tiktok"></a>
                </div>
            </li>
            <hr>
            <li class="list-group-item copyright">
                Copyright © 2023 Sekayu Catering
            </li>
        </ul>
    </div>
</div>
