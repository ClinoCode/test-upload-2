<div class="hasil-hitung">
    <h4 class="mb-3">Hasil Hitung</h4>
    <p>Kebutuhan kalori harian kamu adalah {{ $tdee }} kkal
        hari jika kamu tidak olahraga
        <br>
        Jika Kebutuhan kalori harian kamu adalah 1172 kkal/hari. Berat badan kamu masih Belum Ideal.Jika kamu ingin
        menaikkan berat badan, kamu membutuhkan 1406 kkal/hari Kalori Anda adalah {{ $tdee }} jika tidak
        olahraga
    </p>
</div>
